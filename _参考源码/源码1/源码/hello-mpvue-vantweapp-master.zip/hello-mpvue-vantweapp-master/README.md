# hello-mpvue-vantweapp

> 有赞组件库Vant Weapp是一个伟大的工程，其与美团创建的基于Vue.js的小程序开发框架Mpvue可谓珠联璧合。遗憾的是，Vant Weapp官方展示仅给出了在小程序原生框架下的在线举例，本项目意在提供此组件库在Mpvue框架下的全面展示。Vant Weapp＋Mpvue方案的初学者可参考一下；同时，欢迎提供宝贵意见与建议！！！
请各位注意：我并没有上传node_modules和使用npm run build（或者npm run dev）编译生成的dist文件夹下大量内容。相信各位能够理解，有问题共同讨论...

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

# 参考
1. http://mpvue.com/，美团框架Mpvue官方地址。
2. https://youzan.github.io/vant-weapp/#/quickstart，有赞组件库官方地址，其在此提供的是Vant Weapp组件在小程序原生框架下使用举例，且其中存在极小的BUG，请同学们多留意。
